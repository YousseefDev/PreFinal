import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss']
})
export class AdminDashboardComponent implements OnInit {
  
  authRequests: any[] = [];
  leaveRequests: any[] = [];
  loanRequests: any[] = [];
  personalSituationRequests: any[] = [];
  documentRequests: any[] = [];
  pendingAuthRequestsCount: number = 0;
  pendingLeaveRequestsCount: number = 0;
  showProfile: boolean  = false;
  showMenu: boolean = false;
  selectedRequestType: string | null = null;

  currentPage: string = 'authRequests'; // Default page
  showRhRequestMenu: boolean | undefined;

  constructor(private apiService: ApiService, private authService: AuthService,private router: Router) {}

  ngOnInit(): void {
    // Initially load all requests
    this.getAuthRequests();
    this.getLeaveRequests();
    this.getPendingAuthRequestsCount();
    this.getPendingLeaveRequestsCount();
    // HR view
    this.getLoanRequests();
    this.getPersonalSituationRequests();
    this.getDocumentRequests();
  }


  getSenderFullName(request: any): string {
    return request.senderFullName || 'Unknown';
  }
  logout(): void {
    this.authService.logout();
  }
  updateAuthRequestStatus(requestId: number, newStatus: string, response: string): void {
    this.apiService.updateAuthRequestStatusAndResponse(requestId, newStatus, response).subscribe(
      (data: any) => {
        this.getAuthRequests(); // Refresh the list of requests after updating status
        this.showProfile = false;
      },
      (error) => {
        console.log(error);
      }
    );
  }

  updateLeaveRequestStatus(requestId: number, isApproved: boolean, response?: string): void {
    this.apiService.updateLeaveRequestStatusAndResponse(requestId, isApproved, response).subscribe(
      (data: any) => {
        this.getLeaveRequests(); // Refresh the list of requests after updating status
        this.showProfile = false;
      },
      (error) => {
        console.log(error);
      }
    );
  }
  

  getPendingAuthRequestsCount(): void {
    this.apiService.getPendingAuthRequestsCount().subscribe(
      (count: number) => this.pendingAuthRequestsCount = count,
      (error: any) => console.error('Failed to get pending auth requests count', error)
    );
  }

  getPendingLeaveRequestsCount(): void {
    this.apiService.getPendingLeaveRequestsCount().subscribe(
      (count: number) => this.pendingLeaveRequestsCount = count,
      (error: any) => console.error('Failed to get pending leave requests count', error)
    );
  }

  getAuthRequests(): void {
    this.apiService.getAuthRequests().subscribe(data => this.authRequests = data);
    this.showProfile = false;
  }

  getLeaveRequests(): void {
    this.apiService.getHrApprovedLeaveRequests().subscribe(data => this.leaveRequests = data);
    this.showProfile = false;
  }

  // HR view
  updateLoanRequestStatus(requestId: number, newStatus: string, response: string): void {
    this.apiService.updateLoanRequestStatusAndResponse(requestId, newStatus, response).subscribe(
      (data: any) => {
        const index = this.loanRequests.findIndex(request => request.id === requestId);
        if (index !== -1) {
          this.loanRequests[index].status = newStatus;
          this.showProfile = false;
        }
      },
      (error) => {
        console.log(error);
      }
    );
  }

  updatePersonalSituationRequestStatus(requestId: number, newStatus: string, response: string): void {
    this.apiService.updatePersonalSituationRequestStatusAndResponse(requestId, newStatus, response).subscribe(
      (data: any) => {
        const index = this.personalSituationRequests.findIndex(request => request.id === requestId);
        if (index !== -1) {
          this.personalSituationRequests[index].status = newStatus;
          this.showProfile = false;
        }
      },
      (error) => {
        console.log(error);
      }
    );
  }

  updateDocumentRequestStatus(requestId: number, newStatus: string, response: string): void {
    this.apiService.updateDocumentRequestStatusAndResponse(requestId, newStatus, response).subscribe(
      (data: any) => {
        const index = this.documentRequests.findIndex(request => request.id === requestId);
        if (index !== -1) {
          this.documentRequests[index].status = newStatus;
          this.showProfile = false;
        }
      },
      (error) => {
        console.log(error);
      }
    );
  }

  getLoanRequests(): void {
    this.apiService.getLoanRequests().subscribe(data => this.loanRequests = data);
    this.showProfile = false;
  }

  getPersonalSituationRequests(): void {
    this.apiService.getPersonalSituationRequests().subscribe(data => this.personalSituationRequests = data);
    this.showProfile = false;
  }

  getDocumentRequests(): void {
    this.apiService.getDocumentRequests().subscribe(data => this.documentRequests = data);
    this.showProfile = false;
  }

  setCurrentPage(page: string): void {
    this.currentPage = page;
    this.loadCurrentPageData();
    this.showProfile = false;
  }

  loadCurrentPageData(): void {
    switch (this.currentPage) {
      case 'authRequests':
        this.getAuthRequests();
        break;
      case 'leaveRequests':
        this.getLeaveRequests();
     
    }
  }

  navigateToProfile(): void {
    this.router.navigate(['profile']);
    
  }

  showUserProfile(): void {
    this.showProfile = true;
    this.currentPage = '';
  }

  toggleRhRequestMenu(): void {
    this.showRhRequestMenu = !this.showRhRequestMenu;
  }
  

}
