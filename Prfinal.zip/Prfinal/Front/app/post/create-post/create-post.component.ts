// src/app/create-post/create-post.component.ts
import { Component, EventEmitter, Output } from '@angular/core';

import { Router } from '@angular/router';
import { PostService } from '../post.service';
import { Post } from '../post.model';

@Component({
  selector: 'app-create-post',
  templateUrl: './create-post.component.html',
  styleUrls: ['./create-post.component.scss']
})
export class CreatePostComponent {
  @Output() newPost = new EventEmitter<Post>();

  post: Post = {
    title: '',
    subject: '',
    imageUrl: ''
  };

  constructor(private postService: PostService) {}

  submitPost(): void {
    this.postService.addPost(this.post).subscribe(
      post => {
        this.newPost.emit(post);
        this.post = { title: '', subject: '', imageUrl: '' }; // Reset form
      },
      error => console.error('Error submitting post:', error)
    );
  }
}
