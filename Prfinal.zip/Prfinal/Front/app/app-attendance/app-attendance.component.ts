  import { Component, OnInit } from '@angular/core';
  import { ApiService } from '../api.service';
import { ActivatedRoute } from '@angular/router';

  @Component({
    selector: 'app-attendance',
    templateUrl: './app-attendance.component.html',
    styleUrls: ['./app-attendance.component.scss']
  })
  export class AttendanceComponent implements OnInit {
    userId: number | null; // Nullable type for userId
    attendanceRecords: FormattedAttendance[] = [];

    constructor(
      private apiService: ApiService,
      private route: ActivatedRoute
    ) {
      this.userId = null; // Initialize userId as null initially
    }


     ngOnInit(): void {
    const userId = +this.route.snapshot.paramMap.get('id')!;
    if (userId) {
      console.log('Fetching attendance for user ID:', userId);
      this.userId = userId;
      this.fetchAttendance();
    }}
    checkIn(): void {
      if (this.userId === null) {
        console.error('User ID is null. Cannot perform check-in.');
        return;
      }
      
      this.apiService.checkIn(this.userId).subscribe(
        attendance => {
          console.log('Check-in successful:', attendance);
          this.fetchAttendance(); // Refresh attendance records
        },
        error => {
          console.error('Error during check-in:', error);
        }
      );
    }
    
    checkOut(): void {
      if (this.userId === null) {
        console.error('User ID is null. Cannot perform check-out.');
        return;
      }
      
      this.apiService.checkOut(this.userId).subscribe(
        attendance => {
          console.log('Check-out successful:', attendance);
          this.fetchAttendance(); // Refresh attendance records
        },
        error => {
          console.error('Error during check-out:', error);
        }
      );
    }
    
    fetchAttendance(): void {
      if (!this.userId) {
        console.error('User ID is not set.');
        return;
      }
      this.apiService.getUserAttendance(this.userId).subscribe(
        attendanceRecords => {
          console.log('Raw attendance records:', attendanceRecords);
          this.attendanceRecords = this.formatAttendanceRecords(attendanceRecords);
          console.log('Formatted attendance records:', this.attendanceRecords);
        },
        error => {
          console.error('Error fetching attendance records:', error);
        }
      );
    }
    formatTime(timeString: string | null): string {
      if (!timeString || typeof timeString !== 'string') {
        return ''; // Return empty string for null, undefined, or non-string values
      }
      // Split the timeString to get hours and minutes
      const [hours, minutes] = timeString.split(':');
      // Return formatted time HH:mm
      return `${hours}:${minutes}`;
    }
  
    // Method to format attendance records
    formatAttendanceRecords(records: any[]): any[] {
      // Example logic to format each record's time fields
      return records.map(record => ({
        ...record,
        checkInTime: this.formatTime(record.checkInTime),
        checkOutTime: this.formatTime(record.checkOutTime)
      }));
    }
  }  


  interface Attendance {
    id: number;
    user: User;
    date: string;
    checkInTime: string;
    checkOutTime: string | null;
  }

  interface FormattedAttendance {
    id: number;
    user: User;
    date: string;
    checkInTime: string;
    checkOutTime: string | null;
  }

  interface User {
    id: number;
    fullName: string;
    email: string;
    // Add other user properties as needed
  }
