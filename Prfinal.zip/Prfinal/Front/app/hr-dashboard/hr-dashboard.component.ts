import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';



@Component({
  selector: 'app-hr-dashboard',
  templateUrl: './hr-dashboard.component.html',
  styleUrls: ['./hr-dashboard.component.scss']
})
export class HrDashboardComponent implements OnInit {

  loanRequests: any[] = [];
  personalSituationRequests: any[] = [];
  documentRequests: any[] = [];
  leaveRequests: any[] = [];
  pendingLoanRequestsCount: number = 0;
  pendingPersonalSituationRequestsCount: number = 0;
  pendingDocumentRequestsCount: number = 0;
  currentSection: string ='';
  showProfile: boolean  = false;
  currentPage: string = 'authRequests'; // Default page


  constructor(private apiService: ApiService,
    private authService: AuthService ,// Injectez AuthService ici
    private router: Router
  ) {}

  ngOnInit(): void {
    // Initially load all requests
    this.getLoanRequests();
    this.getPersonalSituationRequests();
    this.getPendingDocumentRequests();
    this.getLeaveRequests();  
    this.getPendingLoanRequestsCount();
    this.getPendingPersonalSituationRequestsCount();
    this.getPendingDocumentRequestsCount();

  }
 
  getLeaveRequests(): void {
    this.apiService.getAdminLeaveRequests().subscribe(data => this.leaveRequests = data);
    this.showProfile=false;
    this.currentSection='';
  }
  
 

  getPendingLoanRequestsCount(): void {
    this.apiService.getPendingLoanRequestsCount().subscribe(
      (count: number) => this.pendingLoanRequestsCount = count,
      (error: any) => console.error('Failed to get pending loan requests count', error)
    );    

  }

  getPendingPersonalSituationRequestsCount(): void {
    this.apiService.getPendingPersonalSituationRequestsCount().subscribe(
      (count: number) => this.pendingPersonalSituationRequestsCount = count,
      (error: any) => console.error('Failed to get pending personal situation requests count', error)
    );
  }

  getPendingDocumentRequestsCount(): void {
    this.apiService.getPendingDocumentRequestsCount().subscribe(
      (count: number) => this.pendingDocumentRequestsCount = count,
      (error: any) => console.error('Failed to get pending document requests count', error)
    );
  }

  updateLoanRequestStatus(requestId: number, newStatus: string, response: string): void {
    this.apiService.updateLoanRequestStatusAndResponse(requestId, newStatus, response).subscribe(
      (data: any) => {
        // Update the status of the specific request in the local array
        const index = this.loanRequests.findIndex(request => request.id === requestId);
        if (index !== -1) {
          this.loanRequests[index].status = newStatus;
        }
        this.showProfile=false;
        this.currentSection='';
      
      },
      (error) => {
        console.log(error);
      }
    );
  }

  updatePersonalSituationRequestStatus(requestId: number, newStatus: string, response: string): void {
    this.apiService.updatePersonalSituationRequestStatusAndResponse(requestId, newStatus, response).subscribe(
      (data: any) => {
        // Update the status of the specific request in the local array
        const index = this.personalSituationRequests.findIndex(request => request.id === requestId);
        if (index !== -1) {
          this.personalSituationRequests[index].status = newStatus;
        }
        this.showProfile=false;
        this.currentSection='';

      },
      (error) => {
        console.log(error);
      }
    );

  }

  updateDocumentRequestStatus(requestId: number, newStatus: string, response: string): void {
    this.apiService.updateDocumentRequestStatusAndResponse(requestId, newStatus, response).subscribe(
      (data: any) => {
        // Update the status of the specific request in the local array
        const index = this.documentRequests.findIndex(request => request.id === requestId);
        if (index !== -1) {
          this.documentRequests[index].status = newStatus;
        }
        this.showProfile=false;
        this.currentSection='';
      },
      (error) => {
        console.log(error);
      }
    );
  }


  getLoanRequests(): void {
    this.apiService.getLoanRequests().subscribe(data => this.loanRequests = data);
    this.showProfile=false;
    this.currentSection='';
  }

  getPersonalSituationRequests(): void {
    this.apiService.getPersonalSituationRequests().subscribe(data => this.personalSituationRequests = data);
    this.showProfile=false;
    this.currentSection='';
  }

  getPendingDocumentRequests(): void {
    this.apiService.getPendingDocumentRequests().subscribe(data => this.documentRequests = data);
    this.showProfile=false;
    this.currentSection='';
  }

  loadLeaveRequests(): void {
    this.apiService.getLeaveRequests().subscribe((data) => {
    this.leaveRequests = data;
    this.showProfile=false;
    this.currentSection='';
    });}

    approveLeaveRequest(requestId: number, response: string): void {
      this.apiService.approveLeaveRequestByHR(requestId, response).subscribe((data) => {
        console.log('Request approved', data);
        this.loadLeaveRequests(); // Recharger les demandes après approbation
        this.showProfile=false;
        this.currentSection=''; // Réinitialiser currentSection à une valeur vide
      });
    }
    
    denyLeaveRequest(requestId: number, response: string): void {
      this.apiService.denyLeaveRequestByHR(requestId, response).subscribe((data) => {
        console.log('Request denied', data);
        this.showProfile=false;
        this.currentSection=''; // Réinitialiser currentSection à une valeur vide
        this.loadLeaveRequests(); // Recharger les demandes après refus
      });
    }

    
    

  showSection(section: string): void {
    this.currentSection = section;
    this.showProfile=false;

  }
  setCurrentPage(page: string): void {
    this.currentPage = page;
    this.showProfile = false;
  }

  logout(): void {
    this.authService.logout();
  }

  navigateToProfile(): void {
    this.router.navigate(['profile']);
    
  }
 

  showUserProfile(): void {
    this.showProfile = true;
    this.currentSection='';
  }
  
}
