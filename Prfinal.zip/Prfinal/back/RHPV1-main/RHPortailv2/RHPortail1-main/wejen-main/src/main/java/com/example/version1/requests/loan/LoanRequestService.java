package com.example.version1.requests.loan;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LoanRequestService {

    @Autowired
    private LoanRequestRepository loanRequestRepository;

    public LoanRequest createLoanRequest(LoanRequest loanRequest, Long userId) {
        return loanRequestRepository.save(loanRequest);

    }
    public List<LoanRequest> getAllLoanRequests() {
        return loanRequestRepository.findAll();
    }
    public List<LoanRequest> getPendingLoanRequests() {
        return loanRequestRepository.findByStatus("pending");
    }
    public LoanRequest updateLoanRequestStatusAndResponse(Long id, String newStatus, String response) {
        LoanRequest request = loanRequestRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Loan request not found with ID: " + id));

        request.setStatus(newStatus);
        request.setResponse(response);

        return loanRequestRepository.save(request);
    }

    public int countPendingLoanRequests() {
        return loanRequestRepository.countByStatus("pending");

    }

    public List<LoanRequest> getLoanRequestsByUserId(Long userId) {
        return loanRequestRepository.findByUserId(userId);
    }

}
