package com.example.version1.attendence;

import com.example.version1.attendence.Attendance;
import com.example.version1.attendence.AttendanceRepository;
import com.example.version1.users.User;
import com.example.version1.users.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;


    @Service
    public class AttendanceService {

        @Autowired
        private AttendanceRepository attendanceRepository;

        @Autowired
        private UserRepository userRepository;

        public Attendance checkIn(Long userId) {
            User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
            Attendance attendance = new Attendance();
            attendance.setUser(user);
            attendance.setDate(LocalDate.now());
            attendance.setCheckInTime(LocalTime.now());
            return attendanceRepository.save(attendance);
        }

        public Attendance checkOut(Long userId) {
            User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
            Attendance attendance = attendanceRepository.findTopByUserAndDateOrderByCheckInTimeDesc(user, LocalDate.now())
                    .orElseThrow(() -> new RuntimeException("Check-in record not found"));
            attendance.setCheckOutTime(LocalTime.now());
            return attendanceRepository.save(attendance);
        }

        public List<Attendance> getUserAttendance(Long userId) {
            User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
            return attendanceRepository.findByUserId(userId);
        }
    }
