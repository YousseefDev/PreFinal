    package com.example.version1.requests;

    import com.example.version1.requests.DTO.LeaveRequestDTO;
    import com.example.version1.requests.Leave.LeaveRequest;
    import com.example.version1.users.User;
    import com.example.version1.users.UserRepository;
    import jakarta.validation.Valid;
    import java.util.Arrays;
    import java.util.List;
    import java.util.Optional;
    import java.util.stream.Collectors;
    import javax.naming.AuthenticationException;
    import lombok.RequiredArgsConstructor;
    import org.slf4j.Logger;
    import org.slf4j.LoggerFactory;
    import org.springframework.http.HttpStatus;
    import org.springframework.http.ResponseEntity;
    import org.springframework.security.core.Authentication;
    import org.springframework.security.oauth2.jwt.Jwt;
    import org.springframework.web.bind.annotation.*;

@RestController 
@RequestMapping("api/v1/requests")
@RequiredArgsConstructor
public class ApiRequestController {
  private final RequestService requestService;
  private final UserRepository userRepository; // Inject UserRepository

  @GetMapping
  public ResponseEntity<List<Request>> getAll() {
    List<Request> requests = requestService.getAllRequest();
    return new ResponseEntity<>(requests, HttpStatus.OK);
  }

  private static final Logger logger = LoggerFactory.getLogger(ApiRequestController.class);

  // CHANGED
  @PostMapping("/Send-req")
  public ResponseEntity<Request> createRequest(
      @RequestBody Request request, Authentication authentication) throws AuthenticationException {
    if (authentication == null
        || !authentication.isAuthenticated()
        || !(authentication.getPrincipal() instanceof Jwt)) {
      throw new AuthenticationException("Authentication is missing or invalid for this request");
    }

    Jwt jwtToken = (Jwt) authentication.getPrincipal();

    // Extract user email (sub) from JWT claims
    String userEmail = jwtToken.getClaim("sub");

    // Find user by email in your database
    Optional<User> userOptional = userRepository.findByEmail(userEmail);
    if (userOptional.isEmpty()) {
      throw new AuthenticationException("User not found");
    }
    User user = userOptional.get();

    Long userId = user.getId(); // Get the user ID from the retrieved user object

    // Set user ID and sender's full name in the request object

    request.setUserId(userId);
    request.setSenderFullName(user.getFullName()); // Set sender's full name

    Request createdRequest = requestService.createRequest(request, userId);
    return new ResponseEntity<>(createdRequest, HttpStatus.CREATED);
  }

  @GetMapping("/my-requests")
  public ResponseEntity<List<Request>> getMyRequests(Authentication authentication)
      throws AuthenticationException {
    if (authentication == null || !authentication.isAuthenticated()) {
      throw new AuthenticationException("User not authenticated");
    }

    // Extract user email from JWT claims
    Jwt jwtToken = (Jwt) authentication.getPrincipal();
    String userEmail = jwtToken.getClaim("sub");

    // Find user by email in your database
    Optional<User> userOptional = userRepository.findByEmail(userEmail);
    if (userOptional.isEmpty()) {
      throw new AuthenticationException("User not found");
    }
    User user = userOptional.get();

    // Extract user ID
    Long userId = user.getId();

    // Retrieve requests created by the user from different tables
    List<Request> userRequests = requestService.getRequestsByUserId(userId);

    return new ResponseEntity<>(userRequests, HttpStatus.OK);
  }
    @GetMapping("/users")
    public List<User> getAllUsers() {
        // Logic to fetch all users from the database
        return userRepository.findAll();
    }
       }








