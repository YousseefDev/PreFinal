package com.example.version1.Model;

public enum RoleEnum {
    EMPLOYEE,
    ADMIN,
    RH

}

